-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (native)
Source: debpic
Binary: debpic
Architecture: all
Version: 1.0.0
Maintainer: Aidan Gallagher <apjgallagher@gmail.com>
Homepage: https://github.com/aidan-gallagher/debpic
Standards-Version: 4.6.2
Vcs-Browser: https://github.com/aidan-gallagher/debpic
Vcs-Git: https://github.com/aidan-gallagher/debpic.git
Build-Depends: debhelper-compat (= 13), dh-exec, pandoc
Package-List:
 debpic deb misc optional arch=all
Checksums-Sha1:
 8ee8ecd1e341435d6fa553d340e3898d2832472d 194524 debpic_1.0.0.tar.xz
Checksums-Sha256:
 3ff659bc17e705de6a994d70626ede41733dc4b6f9d6d0d02a45a8f826d2910d 194524 debpic_1.0.0.tar.xz
Files:
 786fc319e3f71c01ecc0fa3b0639a6b7 194524 debpic_1.0.0.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJLBAEBCgA1FiEEV4VBFG28ZibOhwX5mUVpMELbkd8FAmdTLh4XHGFwamdhbGxh
Z2hlckBnbWFpbC5jb20ACgkQmUVpMELbkd+Agg//TCjzC9+3UZsFIK0rYCEVjBAF
I17NzjNVjfuzLSv0GrqZlsLnyzCHZBS80jq0fIZT7Km2u7bnKJ0b9wQp8A45Hnoj
MRBP02vOHFdGpTLwpCkE43NWdQfTPNMq9iBt0yUclGjkozWgD+B3POt01YU/8wIq
pAUBQwBUm+0K1GBmTU1wHlANSQpMuZJthizhIOdyopbdu05zIbh88Fssu8A1QE5V
/PrVc5TtYRgtqLCsCH/fO8GikxmdwpNhLcPn6ZdJ/qk85gl5OOZvSs3aggKlumbg
pAoU/LQn5OhsnCW+nc347tMfMon85+3Iz3zAe19WhSa6zb/TOmfVgrkkXXaasLbf
ZRiRFsOQK9vZuvd4cKa9F7IjS3jMXPmuTFKdUevxY+KCFDk/91ifWF4prBKWNBAZ
6mYUMpxwQF/alR0Gkf42N3pyEq0rYWq/Kjp0g5JxqW7XHDl7BoxRYWNDnfcodeAu
q9W0dEWwwaW/dVqVUnaltx/AqIvaGoOPni6ZurWwTn+0ASkciZHkQBSriWlA7ey1
wydrTAXpfpPPcX+DsEAPos5x+CwT4x24OSc30Obf7ll5IZ7is6e3zp4tP0rASGP0
4BdwbtmObMAkInUdc1Xwhs93G8yhJtvoYBAemdMqcbU5JG8D8yaQNgrSfinDpk2Q
GweslBRr90DHMn+CYHw=
=eeu3
-----END PGP SIGNATURE-----
